alert('employregi.js called');
$(document).ready(function(){

	    alert("employregi.js called inside ready function");


	     $("#submit").click(function(){	   
	
	      $.ajax({
	           type: 'GET',
	           url: '/bin/jsonread',
	          contentType:'application/json',
	          dataType: 'json',	         
	          success: function(result){
                  var result = jQuery.parseJSON(json);
                 // alert(result.EmployeeId + ""+result.Name +""+result.isPermanent +""+result.Nickname);
	        	  //result.EmployeeId;

              // var EmployeeId= result.EmployeeId;
              // var Name = result.Name;
              // var Salary = result.Salary;
              //  var isPermanent = result.isPermanent;
              // var Nickname = result.Nickname;   

                //  $('#id').html(EmployeeId);
                 //   $('#name').html(Name);
                 //   $('#salary').html(Salary);
                  //  $('#isperm').html(isPermanent);
                  //  $('#nickname').html(Nickname);


	        },
	        error: function(err) {
	             alert("Unable to retrive data "+err);
	        }
	    });
	         });

	});
